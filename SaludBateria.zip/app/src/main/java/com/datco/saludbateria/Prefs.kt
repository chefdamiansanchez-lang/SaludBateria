package com.datco.saludbateria

import android.content.Context

object Prefs {
    private const val FILE = "salud_bateria"
    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("alert_enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("alert_enabled", v).apply()

    fun threshold(c: Context) = sp(c).getInt("alert_threshold", 80)
    fun setThreshold(c: Context, v: Int) = sp(c).edit().putInt("alert_threshold", v).apply()
}
